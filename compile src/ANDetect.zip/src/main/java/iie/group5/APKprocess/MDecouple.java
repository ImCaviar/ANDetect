package iie.group5.APKprocess;

import iie.group5.structure.Graph;
import iie.group5.structure.Module;
import iie.group5.structure.PackagePoint;
import iie.group5.structure.Smali;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MDecouple {
    private List<File> file;
    private Module initModule;
    private List<Module> modules;
    private Integer ppCount;
    private Map<Integer, PackagePoint> packagePoints;
    private List<Smali> smalis;
    private Map<Integer, Integer> PPID2commID;
    private boolean shelled;


    public MDecouple(List<String> filePath) {
        this.file = new ArrayList<>();
        for (String f : filePath){
            File tmpF = new File(f);
            this.file.add(tmpF);
        }
        this.modules = new ArrayList<>();
        this.packagePoints = new HashMap<>();
        this.smalis = new ArrayList<>();
        this.PPID2commID = new HashMap<>();
        this.shelled = true;
        this.ppCount = 0;
    }

    public List<Module> getModules() {
        return modules;
    }

    public void decoupling(String hostPKG){
        System.out.println("Building package TREEs and Analyzing Smali files!");
        int ind = hostPKG.lastIndexOf(".");
        String host = "";
        if (ind != -1){
            hostPKG = hostPKG.substring(0, ind);
            host = hostPKG.replace(".", "/");
        }
        Integer id = ppCount ++;
        PackagePoint packagePoint = new PackagePoint(id, "classes", null);
        this.packagePoints.put(id, packagePoint);
        for (File f : this.file){
            findFiles(f, id, host);
        }
        if (this.shelled){
            return;
        }
        Graph community = new Graph();
        genGraphbyPkg(community);
        this.initModule = new Module(this.packagePoints, this.smalis);

        System.out.println("Module Decoupling by Louvain!");
        community.singleLouvain();
//        community.outputComm();
        mergeComm(community);
//        outputComm();
        splitSubModule();
//        outputNoName();
    }

    private void findFiles(File file, Integer parentId, String host){
        if (file != null && file.exists()){
            String filePath = file.getPath();
            if (!host.equals("") && filePath.contains(host)){
                this.shelled = false;
                return;
            }
            String fileName = file.getName();
            if (file.isDirectory()){
                Integer id = ppCount ++;
                PackagePoint packagePoint = new PackagePoint(id, fileName, parentId);
                this.packagePoints.put(id, packagePoint);
                File [] subFiles = file.listFiles();
                if (subFiles != null){
                    for (File f : subFiles){
                        findFiles(f, id, host);
                    }
                }
            }else if (fileName.endsWith(".smali")){
                Smali smali = new Smali(parentId);
                smali.analyzeSmali(filePath);
                this.smalis.add(smali);
            }
        }
    }

    private void genGraphbyPkg(Graph community){
        System.out.println("Add Vertices ......");
        for (Smali i : this.smalis){
            Integer ppID = i.getPpID();
            String pkg = getPkg(i.getClazz());
            if (!community.inGraph(pkg) && !pkg.equals("")){
                community.insertVertex(pkg);
            }
            PackagePoint pp = this.packagePoints.get(ppID);
            if (pp.getPkgName().equals("")){
                pp.setPkgName(pkg);
            }
        }
        System.out.println("Generating Call Graph ......");
        for (Smali i: this.smalis){
            String supPkg = getPkg(i.getSupper());
            String pkg = getPkg(i.getClazz());
            if (community.inGraph(supPkg) && !supPkg.equals(pkg) && !pkg.equals("")){
                community.insertEdge(supPkg, pkg, 5);
            }
            String[] invokes = i.getInvoke();
            for (int ind=0; ind<invokes.length; ind++){
                if (invokes[ind] != null){
                    String classn = invokes[ind].split("->")[0];
                    if (classn.contains("[")){
                        classn = classn.replace("[", "");
                    }
                    classn = getPkg(classn);
                    if (community.inGraph(classn) && !pkg.equals("")){
                        i.setInvoketoCtm(ind);
                        if (!classn.equals(pkg)){
                            community.insertEdge(pkg, classn, 1);
                        }
                    }
                }
            }
        }
    }

    private String getPkg(String clazz){
        String result = "";
        if (clazz.contains("/")){
            int ind = clazz.lastIndexOf("/");
            result = clazz.substring(0, ind);
        }
        return result;
    }

    private void mergeComm(Graph community){
        for (Integer i : this.packagePoints.keySet()){
            String pkg = this.packagePoints.get(i).getPkgName();
            Integer commID = -1;
            if (!pkg.equals("")){
                commID = community.commIDbyLable(pkg);
                int contribute = community.commContribute(pkg);
                this.initModule.setContribute(i, contribute);
            }
            this.PPID2commID.put(i, commID);
        }
        boolean flag = true;
        while (flag){
            flag = false;
            List<Integer> ppList = this.initModule.getDfsPPList();
            for (Integer i : ppList){
                Map<Integer, PackagePoint> ppMap = this.initModule.getPackagePoints();
                PackagePoint pp = ppMap.get(i);
                Integer ppCommID = this.PPID2commID.get(pp.getId());
                if (pp.getParentId() != null && this.PPID2commID.get(pp.getParentId()) != -1){
                    this.PPID2commID.put(pp.getId(), this.PPID2commID.get(pp.getParentId()));
                    String parentPkg = this.packagePoints.get(pp.getParentId()).getPkgName();
                    String pkgName = parentPkg + "/" + pp.getLabel();
                    this.initModule.setPKGbyID(pp.getId(), pkgName);
                    flag = true;
                    pp.setTerm(true);
                    this.initModule.unlockChild(pp.getId());
                }else if (pp.getChildrenID().size() > 0 &&  ppCommID != -1){
                    pp.setTerm(true);
                }else if(pp.getChildrenID().size() > 0 && ppCommID == -1){
                    Map<Integer, Integer> commID2num = new HashMap<>();
                    Map<Integer, String> commID2pkg = new HashMap<>();
                    double sum = 0;
                    double sort = 0;
                    boolean process = true;
                    for (Integer child : pp.getChildrenID()){
                        Integer childCommID = this.PPID2commID.get(child);
                        if (childCommID == -1){
                            process = false;
                            break;
                        }else {
                            if (!commID2num.containsKey(childCommID)){
                                commID2num.put(childCommID, 1);
                                String pkg = getPkg(this.initModule.findPKGbyID(child));
                                // PP节点完整包名为空，则停止合并
                                if (pkg.equals("")){
                                    pp.setTerm(true);
                                    process = false;
                                    break;
                                }
                                commID2pkg.put(childCommID, pkg);
                                sort += 1;
                            }else {
                                commID2num.put(childCommID, commID2num.get(childCommID)+1);
                            }
                            sum += 1;
                        }
                    }
                    if (process){
                        String lastPkg = "";
                        int pkgNum = 0;
                        double maxComm = 0;
                        int maxItem = -1;
                        String pkg = "";
                        for (Integer item : commID2num.keySet()){
                            double countComm = commID2num.get(item)/sum;
                            String pkg1 = commID2pkg.get(item);
                            if (countComm > maxComm){
                                maxComm = countComm;
                                maxItem = item;
                                pkg = pkg1;
                            }
                            if (!pkg.equals(lastPkg)){
                                lastPkg = pkg1;
                                pkgNum += 1;
                            }
                        }
                        if (maxComm > 1/sort || commID2num.keySet().size() == 1){
                            this.PPID2commID.put(pp.getId(), maxItem);
                            this.initModule.setPKGbyID(pp.getId(), pkg);
                            flag = true;
                            this.initModule.unlockChild(pp.getId());
                            break;
                        }
                        if (pkgNum == 1 && sum == sort){
                            String tmp = lastPkg.replace("/", "");
                            int count = lastPkg.length()-tmp.length();
                            if (count >= 2){
                                Integer countComm = countPPinComm(commID2num);
                                this.PPID2commID.put(pp.getId(), countComm);
                                this.initModule.setPKGbyID(pp.getId(), lastPkg);
                                flag = true;
                                this.initModule.unlockChild(pp.getId());
                            }
                        }
                        pp.setTerm(true);
                    }
                }else {
                    pp.setTerm(true);
                }
            }
            this.initModule.updatePPList();
        }
    }

    private Integer countPPinComm(Map<Integer,Integer> commID2num){
        Map<Integer, List<Integer>> commID2PPID = new HashMap<>();
        for (Integer i : this.PPID2commID.keySet()){
            Integer commID = this.PPID2commID.get(i);
            List<Integer> ppList;
            if (!commID2PPID.containsKey(commID)){
                ppList = new ArrayList<>();
            }else{
                ppList = commID2PPID.get(commID);
            }
            ppList.add(i);
            commID2PPID.put(commID, ppList);
        }
        int maxNum = 0;
        Integer maxComm = -1;
        for (Integer item : commID2num.keySet()){
            int len = commID2PPID.get(item).size();
            if (len > maxNum){
                maxNum = len;
                maxComm = item;
            }
        }
        return maxComm;
    }


    private void outputComm(){
        Map<Integer, List<Integer>> commID2PPID = new HashMap<>();
        for (Integer i : this.PPID2commID.keySet()){
            Integer commID = this.PPID2commID.get(i);
            List<Integer> ppList;
            if (!commID2PPID.containsKey(commID)){
                ppList = new ArrayList<>();
            }else{
                ppList = commID2PPID.get(commID);
            }
            ppList.add(i);
            commID2PPID.put(commID, ppList);
        }
        for (Integer commID : commID2PPID.keySet()){
            List<Integer> ppList = commID2PPID.get(commID);
            if (ppList.size() > 0){
                System.out.printf("-----------Community %d----------\n", commID);
                for (Integer ppID : ppList){
                    System.out.printf("%d: %s\n", ppID, this.initModule.findPKGbyID(ppID));
                }
            }
        }
    }

    private void splitSubModule(){
        Map<Integer, List<Integer>> commID2PPID = new HashMap<>();
        for (Integer i : this.PPID2commID.keySet()){
            Integer commID = this.PPID2commID.get(i);
            if (commID != -1){
                List<Integer> ppList;
                if (!commID2PPID.containsKey(commID)){
                    ppList = new ArrayList<>();
                }else{
                    ppList = commID2PPID.get(commID);
                }
                ppList.add(i);
                commID2PPID.put(commID, ppList);
            }
        }
        for (Integer commID : commID2PPID.keySet()){
            List<Integer> ppList = commID2PPID.get(commID);
            if (ppList.size() > 0){
                List<PackagePoint> newPP = new ArrayList<>();
                List<Smali> newSmali = new ArrayList<>();
                for (Integer ppID : ppList){
                    List<PackagePoint> twig = this.initModule.findTwigbyID(ppID);
                    for (PackagePoint pp : twig){
                        List<Smali> smalis = this.initModule.findSmalibyID(pp.getId());
                        if (!newPP.contains(pp)){
                            newPP.add(pp);
                            newSmali.addAll(smalis);
                        }
                    }
                }
                List<PackagePoint> roots = getRootfromTrees(newPP);
                if (roots.size() == 1){
                    for (PackagePoint pp : newPP){
                        if (roots.contains(pp)){
                            pp.setParentId(null);
                        }
                    }
                }else if (roots.size() > 1){
                    PackagePoint newp = new PackagePoint(0, "", null);
                    newPP.add(newp);
                    for (PackagePoint pp : newPP){
                        if (roots.contains(pp)){
                            pp.setParentId(0);
                        }
                    }
                }
                mergeSamePP(newPP, newSmali);
                for (int i=0; i<newPP.size(); i++){
                    newPP.set(i, new PackagePoint(newPP.get(i)));
                }
                Module module = new Module(newPP, newSmali);
                genModuleName(module);
                this.modules.add(module);
            }
        }
    }

    private List<PackagePoint> getRootfromTrees(List<PackagePoint> trees){
        List<PackagePoint> roots = new ArrayList<>();
        for (PackagePoint pp : trees){
            PackagePoint tmp = pp;
            while (trees.contains(this.packagePoints.get(tmp.getParentId()))){
                tmp = this.packagePoints.get(tmp.getParentId());
            }
            if (!roots.contains(tmp)){
                roots.add(tmp);
            }
        }
        return roots;
    }

    private void genModuleName(Module module){
        PackagePoint root = module.findRoot();
        if (!root.getLabel().equals("")){
            PackagePoint pp = module.findSingle(root.getId());
            if (!pp.getPkgName().equals("") && pp.getPkgName().contains("/")){
                module.setName(pp.getPkgName());
                return;
            }
        }
        Map<String,Integer> candi = new HashMap<>();
        recExcept(module, root, candi);
        int max = 0;
        String name = "";
        for (String s : candi.keySet()){
            int tmp = candi.get(s);
            if (tmp > max){
                max = tmp;
                name = s;
            }
        }
        module.setName(name);
    }

    private void recExcept(Module module, PackagePoint root, Map<String,Integer> map){
        List<Integer> childIDs = root.getChildrenID();
        Map<Integer,PackagePoint> tmp = module.getPackagePoints();
        for (Integer i : childIDs){
            PackagePoint pp = module.findSingle(i);
            String name = pp.getPkgName();
            if (name.equals("") || (!name.contains("/") && name.length()<4)){
                recExcept(module, tmp.get(i),map);
            }else{
                int weight = module.getCTBbyID(i);
                map.put(name, weight);
            }
        }
    }

    private void outputNoName(){
        for (Module m : this.modules){
            if (m.getName().equals("")){
                List<Integer> allPP = m.getDfsPPList();
                System.out.printf("------------------\n");
                for (Integer i : allPP){
                    System.out.printf("%s %d\n", m.findPKGbyID(i),m.getCTBbyID(i));
                }
            }
        }
    }

    private void mergeSamePP(List<PackagePoint> ppList, List<Smali> sList){
        Map<Integer, List<Smali>> smali2parent = new HashMap<>();
        for (Smali s : sList){
            Integer pID = s.getPpID();
            if (!smali2parent.containsKey(pID)){
                List<Smali> smalis = new ArrayList<>();
                smalis.add(s);
                smali2parent.put(pID, smalis);
            }else{
                smali2parent.get(pID).add(s);
            }
        }
        Map<Integer, PackagePoint> ID2PP = new HashMap<>();
        for (PackagePoint pp : ppList){
            ID2PP.put(pp.getId(), pp);
        }
        for (int i1=0; i1<ppList.size(); i1++){
            for (int i2=i1+1; i2<ppList.size(); i2++){
                PackagePoint pp1 = ppList.get(i1);
                PackagePoint pp2 = ppList.get(i2);
                if (pp1.getParentId() == null || pp2.getParentId() == null){
                    continue;
                }
                if (!pp1.equals(pp2) && pp1.getParentId().equals(pp2.getParentId()) && pp1.getLabel().equals(pp2.getLabel()) && pp1.getPkgName().equals(pp2.getPkgName()) && !pp1.getPkgName().equals("")){
                    if (pp1.getChildrenID().size() >= pp2.getChildrenID().size()){
                        Integer newParent = pp1.getId();
                        List<Integer> pp2children = pp2.getChildrenID();
                        for (Integer p2c : pp2children){
                            if (!ID2PP.containsKey(p2c)){
                                System.out.printf("PackagePoint's child %d not in ppList!", p2c);
                                break;
                            }
                            ID2PP.get(p2c).setParentId(newParent);
                            pp1.addChildID(p2c);
                        }
                        if (smali2parent.containsKey(pp2.getId())){
                            for (Smali s : smali2parent.get(pp2.getId())){
                                int ind = sList.indexOf(s);
                                sList.get(ind).setPpID(newParent);
                            }
                        }
                        ppList.remove(pp2);
                    }else{
                        Integer newParent = pp2.getId();
                        List<Integer> pp1children = pp1.getChildrenID();
                        for (Integer p2c : pp1children){
                            if (!ID2PP.containsKey(p2c)){
                                System.out.printf("PackagePoint's child %d not in ppList!", p2c);
                                break;
                            }
                            ID2PP.get(p2c).setParentId(newParent);
                            pp2.addChildID(p2c);
                        }
                        if (smali2parent.containsKey(pp1.getId())){
                            for (Smali s : smali2parent.get(pp1.getId())){
                                int ind = sList.indexOf(s);
                                sList.get(ind).setPpID(newParent);
                            }
                        }
                        ppList.remove(pp1);
                    }
                }
            }
        }
    }

    public boolean isShelled() {
        return shelled;
    }
}
