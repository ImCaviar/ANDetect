package iie.group5.APKprocess;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import java.io.*;
import java.util.*;

public class ResProcess {
    //F1 AndroidManifest.xml_manifest_package
    private HashSet<String> all_an;
    //F2 AndroidManifest.xml_manifest uses-permission_android:name
    private HashSet<String> permission;
    //F3 AndroidManifest.xml_manifest application provider_android:authorities
    private HashSet<String> auth;
    //F4 AndroidManifest.xml_manifest application receiver intent-filter action_android:name
    private HashSet<String> intentFilter;
    //F5 AndroidManifest.xml_manifest application activity_android:name
    private HashSet<String> activity;
    //F6 AndroidManifest.xml_manifest application service_android:name
    private HashSet<String> service;
    //F7 AndroidManifest.xml_manifest application receiver_android:name
    private HashSet<String> receiver;
    //F8 res\values\values.xml_resources dimen_name
    private HashSet<String> dimen;
    //F9 res\values\values.xml_resources string_name
    private HashSet<String> stringn;
    //F10 res\values\values.xml_resources declare-styleable attr_name
    private HashSet<String> attr;
    //F11 res\values\values.xml_resources style_name
    private HashSet<String> style;
    private HashSet<String> picNames;
    private String hostPKG;

    public ResProcess() {
        this.all_an = new HashSet<>();
        this.permission = new HashSet<>();
        this.auth = new HashSet<>();
        this.intentFilter = new HashSet<>();
        this.activity = new HashSet<>();
        this.service = new HashSet<>();
        this.receiver = new HashSet<>();
        this.dimen = new HashSet<>();
        this.stringn = new HashSet<>();
        this.attr = new HashSet<>();
        this.style = new HashSet<>();
        this.picNames = new HashSet<>();
        this.hostPKG = "";
    }
    public String parseRes(String AMFile, String ARSCFile, String zipPath) throws Exception {
        parseAM(AMFile);
        parseARSC(ARSCFile);
        paresPic(zipPath);
        return getHostPKG();
    }

    public void parseAM(String AMFile) throws Exception {
        File newAM = editAN(AMFile);
        SAXBuilder reader = new SAXBuilder();
        InputStream is = new FileInputStream(new File(AMFile));
        Document document = reader.build(is);
        Map<String,List<String>> ele2attr = new HashMap<>();
        Element root = document.getRootElement();
        recGetEle(root, "", ele2attr, "");
        String launcher = "";
        String pack = "";
        for (String key : ele2attr.keySet()){
            String prefix = key.split("_")[0];
            String suffix = key.split("_")[1];
            List<String> list = ele2attr.get(key);
            for (String l : list){
                if (suffix.equals("android:name")){
                    this.all_an.add(l);
                    if (prefix.equals("manifest uses-permission")){
                        this.permission.add(l);
                    }else if (prefix.equals("manifest application receiver intent-filter action")){
                        this.intentFilter.add(l);
                    }else if (prefix.equals("manifest application activity")){
                        this.activity.add(l);
                    }else if (prefix.equals("manifest application service")){
                        this.service.add(l);
                    }else if (prefix.equals("manifest application receiver")){
                        this.receiver.add(l);
                    }else if (prefix.equals("manifest application activity intent-filter category") && l.contains("android.intent.category.LAUNCHER") && launcher.equals("")){
                        if (l.contains(";")){
                            String last = l.split(";")[1];
                            int ind = last.lastIndexOf(".");
                            launcher = last.substring(0, ind);
                        }
                    }
                }else if (suffix.equals("android:authorities") && prefix.equals("manifest application provider")){
                    this.auth.add(l);
                }else if (suffix.equals("package") && prefix.equals("manifest")){
                    pack = l;
                }
            }
        }
        if (!launcher.equals("")){
            if (launcher.charAt(0)=='.'){
                this.hostPKG = pack + launcher;
            }else{
                this.hostPKG = launcher;
            }
        }else{
            this.hostPKG = pack;
        }
    }

    private void recGetEle(Element element, String path, Map<String,List<String>> ele2attr, String last){
        List<Attribute> attributes = element.getAttributes();
        String pre;
        if (!path.equals("")){
            pre = path + " " + element.getQualifiedName();
        }else{
            pre = element.getName();
        }
        if (attributes.size() > 0){
            for (Attribute a : attributes){
                String qn = a.getQualifiedName();
                String key = pre+"_"+qn;
                String value = a.getValue();
                if (key.equals("manifest application activity_android:name")){
                    last = value;
                }else if (key.equals("manifest application activity intent-filter category_android:name") && value.equals("android.intent.category.LAUNCHER") && !last.equals("")){
                    value = value + ";" + last;
                    last = "";
                }
                if (ele2attr.containsKey(key)){
                    ele2attr.get(key).add(value);
                }else{
                    List<String> list = new ArrayList<>();
                    list.add(value);
                    ele2attr.put(key, list);
                }
            }
        }
        List<Element> children = element.getChildren();
        for (Element child : children){
            recGetEle(child, pre, ele2attr, last);
        }
    }

    private File editAN(String AMFile) throws IOException {
        File AM_file = new File(AMFile);
        String newAM = AMFile.replace(".xml","_out.xml");
        File new_AM = new File(newAM);
        BufferedReader reader = new BufferedReader(new FileReader(AM_file));
        BufferedWriter writer = new BufferedWriter(new FileWriter(new_AM));
        String line = reader.readLine();
        while (line != null){
            if (!line.contains("android:name=")){
                line = line.replaceFirst("android:=","android:name=");
            }
            int ascii = 97;
            while (line.contains("android:=")){
                line = line.replaceFirst("android:=", "android:"+(char)(ascii)+"=");
                ascii ++;
            }
            writer.write(line + "\n");
            line = reader.readLine();
        }
        writer.flush();
        writer.close();
        return new_AM;
    }

    private void parseARSC(String ARSCFile) throws Exception {
        SAXBuilder reader = new SAXBuilder();
        InputStream is = new FileInputStream(new File(ARSCFile));
        Document document = reader.build(is);
        Element root = document.getRootElement();
        List<Element> children = root.getChildren();
        for (Element child : children){
            String ele = child.getName();
            if (!ele.equals("public")){
                continue;
            }
            List<Attribute> attributes = child.getAttributes();
            if (attributes.size() > 0){
                int flag = 0;
                for (Attribute a : attributes){
                    if (a.getQualifiedName().equals("type")){
                        switch (a.getValue()){
                            case "dimen":
                                flag = 1;
                                break;
                            case "string":
                                flag = 2;
                                break;
                            case "attr":
                                flag = 3;
                                break;
                            case "style":
                                flag = 4;
                                break;
                            default:
                                break;
                        }
                    }else if (a.getQualifiedName().equals("name")){
                        switch (flag){
                            case 1:
                                this.dimen.add(a.getValue());
                                break;
                            case 2:
                                this.stringn.add(a.getValue());
                                break;
                            case 3:
                                this.attr.add(a.getValue());
                                break;
                            case 4:
                                this.style.add(a.getValue());
                                break;
                        }
                    }
                }
            }
        }
    }

    private void paresPic(String zipPath){
        String suffix1 = zipPath + "assets";
        String suffix2 = zipPath + "res";
        File file1 = new File(suffix1);
        File file2 = new File(suffix2);
        if (!file2.exists()){
            suffix2 = zipPath + "r";
            file2 = new File(suffix2);
        }
        findPic(file1);
        File [] subfile2 = file2.listFiles();
        if (subfile2 != null){
            for(File f : subfile2){
                String filename = f.getName();
                if (filename.contains("drawable")){
                    findPic(f);
                }
            }
        }
    }

    private void findPic(File file){
        if (file != null && file.exists()){
            String filename = file.getName();
            if (file.isDirectory()){
                File [] subFiles = file.listFiles();
                if (subFiles != null){
                    for (File f : subFiles){
                        findPic(f);
                    }
                }
            }else{
                List<String> common_prefix = Arrays.asList("btn","abc","ic","icon");
                List<String> pic_suffix = Arrays.asList("xbm","tif","pjp","svgz","jpg","jpeg","ico","tiff","gif","svg","jfif","webp","png","bmp","pjpeg","avif");
                if (filename.contains("_")){
                    String prefix = filename.split("_")[0];
                    if (common_prefix.contains(prefix)){
                        return;
                    }
                }
                if (filename.contains(".")){
                    int ind = filename.lastIndexOf(".");
                    String suffix = filename.substring(ind+1);
                    if (pic_suffix.contains(suffix)){
                        this.picNames.add(filename.substring(0, ind));
                    }
                }
            }
        }
    }

    public HashSet<String> getAll_an() {
        return all_an;
    }

    public void addAll_an(String all_an) {
        this.all_an.add(all_an);
    }

    public HashSet<String> getPermission() {
        return permission;
    }

    public void addPermission(String permission) {
        this.permission.add(permission);
    }

    public HashSet<String> getAuth() {
        return auth;
    }

    public void addAuth(String auth) {
        this.auth.add(auth);
    }

    public HashSet<String> getIntentFilter() {
        return intentFilter;
    }

    public void addIntentFilter(String intentFilter) {
        this.intentFilter.add(intentFilter);
    }

    public HashSet<String> getActivity() {
        return activity;
    }

    public void addActivity(String activity) {
        this.activity.add(activity);
    }

    public HashSet<String> getService() {
        return service;
    }

    public void addService(String service) {
        this.service.add(service);
    }

    public HashSet<String> getReceiver() {
        return receiver;
    }

    public void addReceiver(String receiver) {
        this.receiver.add(receiver);
    }

    public HashSet<String> getDimen() {
        return dimen;
    }

    public void addDimen(String dimen) {
        this.dimen.add(dimen);
    }

    public HashSet<String> getStringn() {
        return stringn;
    }

    public void addStringn(String stringn) {
        this.stringn.add(stringn);
    }

    public HashSet<String> getAttr() {
        return attr;
    }

    public void addAttr(String attr) {
        this.attr.add(attr);
    }

    public HashSet<String> getStyle() {
        return style;
    }

    public void addStyle(String style) {
        this.style.add(style);
    }

    public HashSet<String> getPicNames() {
        return picNames;
    }

    public void addPicNames(String picNames) {
        this.picNames.add(picNames);
    }

    public String getHostPKG() {
        return hostPKG;
    }

    public void setHostPKG(String hostPKG) {
        this.hostPKG = hostPKG;
    }
}
