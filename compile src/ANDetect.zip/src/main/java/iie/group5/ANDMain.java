package iie.group5;

import iie.group5.APKprocess.*;
import iie.group5.TTPprocess.SCprocess;
import iie.group5.TTPprocess.SerialObj;
import iie.group5.TTPprocess.XGBmodel;
import iie.group5.features.ResSetsAndPool;
import iie.group5.structure.Module;
import iie.group5.structure.PackagePoint;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ANDMain {
    public static void main(String[] args) throws Exception{
        if (args.length < 4){
            System.out.print("Please input command: java -jar ANDetect.jar -a [APK PATH] -o [RESULT PATH]");
        }else if (args[0].equals("-a") && args[2].equals("-o")){
            if (args[1].contains(".apk")){
                parseAPK(args[1], args[3]);
            }else{
                System.out.print("Please input command: java -jar ANDetect.jar -a [APK PATH] -o [RESULT PATH]");
            }
        }else{
            System.out.print("Please input command: java -jar ANDetect.jar -a [APK PATH] -o [RESULT PATH]");
        }
    }

    private static void parseAPK(String path, String output) throws Exception {
        File f = new File(output);
        FileOutputStream fos = new FileOutputStream(f);
        OutputStreamWriter osw = new OutputStreamWriter(fos);

        String apkFile = path;
        String apkUnzip = apkFile.replace(".apk","/");
        File tmpF = new File(apkUnzip);
        if (tmpF.exists()){
            FileUtils.deleteQuietly(tmpF);
        }

        APK2dir a2d = new APK2dir(path);
        a2d.decodeAPK();

        System.out.println("Decode APK by Apktool 2.7.0.");

        String AM_path = a2d.getAMPath();
        ResProcess resProcess = new ResProcess();
        String pub_path = a2d.getPubPath();
        String output_path = a2d.getOutputDir();
        String hostPKG = resProcess.parseRes(AM_path, pub_path, output_path);

        List<String> smaliRoot = a2d.getSmaliPath();
        MDecouple mDecouple = new MDecouple(smaliRoot);
        mDecouple.decoupling(hostPKG);
        osw.write("[Encrypted APK]: ");
        if (mDecouple.isShelled()){
            osw.write("Encrypted!");
        }else {
            osw.write("Not Encrypted!");
            System.out.println("Recognize Ad Networks Libraries...");
            List<Module> modules = mDecouple.getModules();
            SerialObj sobj = new SerialObj();
            sobj.setSerPath();
            osw.write("\n[SC Detect Result]: ");
            List<String> hasMatched = new ArrayList<>();
            for (Module m : modules){
                if (m.getName().equals("")){
                    continue;
                }
                List<String> ANs = sobj.getSerPath();
                List<String> candi = getCandiAN(ANs, m);
                if (candi.size() > 0){
                    for (String c : candi){
                        sobj.inputSERsingle(c);
                    }
                    List<Module> candiM = sobj.getModClass();
                    m.simpleType();
                    double maxTMP = 0;
                    String maxFirstV = "";
                    List<String> matchedFirst = new ArrayList<>();
                    for (Module cm : candiM){
                        if (cm.getVersion().contains(".")){
                            String firstELE = cm.getName() + "_" + cm.getVersion().split("\\.")[0];
                            if (!matchedFirst.contains(firstELE)){
                                MatchbySC msc = new MatchbySC(cm,m);
                                double pctM = msc.compAll();
                                if (pctM > maxTMP){
                                    maxTMP = pctM;
                                    maxFirstV = firstELE;
                                }
                                matchedFirst.add(firstELE);
                            }
                        }
                    }

                    double maxMatch = 0.3;
                    String maxM = "";
                    String maxV = "";
                    for (Module cm : candiM){
                        String firstELE = "";
                        if (cm.getVersion().contains(".")){
                            firstELE = cm.getName() + "_" + cm.getVersion().split("\\.")[0];
                        }
                        if (!maxFirstV.equals("") && !firstELE.equals(maxFirstV)){
                            continue;
                        }
                        MatchbySC msc = new MatchbySC(cm,m);
                        double pctM = msc.compAll();
                        if (pctM > maxMatch){
                            maxMatch = pctM;
                            maxM = cm.getName();
                            maxV = cm.getVersion();
                        }
                    }
                    if (!maxM.equals("") && !hasMatched.contains(maxM)){
                        if (!maxV.equals("")){
                            osw.write(maxM + " == version =>" + maxV + ";");
                        }else{
                            osw.write(maxM + ";");
                        }
                        hasMatched.add(maxM);
                    }
                    sobj.clearModClass();
                }else{
                    boolean isAN = recogAN(m, 3);
                    if (isAN  && !hasMatched.contains(m.getName())){
                        osw.write(m.getName().replaceAll("/", ".") + " => New Ad Lib;");
                        hasMatched.add(m.getName());
                    }
                }
            }
        }

        ResSetsAndPool rsap = new ResSetsAndPool();
        double maxTI = rsap.getMaxTI();
        Map<String, ResProcess> an2ResLib = rsap.getAnName2ResLib();
        Map<String, Map<String, Double>> an2tfidf = rsap.getAn2tfidf();
        MatchbyRes mr = new MatchbyRes(resProcess, an2ResLib, an2tfidf, maxTI);
        double thresh = 0.1;
        double pc = 0.1;
        Map<String, Double> ANs = mr.compMaxMatch(thresh, pc);
        osw.write("\n[Res Detect Result]: ");
        if (ANs.size() == 0){
            osw.write("");
        }else{
            for (String r : ANs.keySet()){
                osw.write(r + ";");
            }
        }
        osw.close();
    }

    private static boolean recogAN(Module subM, int str_thresh) throws Exception {
        SCprocess scp = new SCprocess();
        List<float[]> arrays = scp.outputSA(subM);
        XGBmodel xgbM = new XGBmodel();
        float[] results = xgbM.classify(arrays.get(2),arrays.get(3),arrays.get(4));
        boolean API = true;
        boolean str = false;
        for (int i=0; i<results.length; i++){
            if (results[i] < 0.9){
                API = false;
            }
        }
        int count_str = 0;
        for (int i=0; i<arrays.get(0).length; i++){
            if (arrays.get(0)[i] > 0){
                count_str ++;
            }
        }
        if (count_str >= str_thresh){
            str = true;
        }
        return API && str;
    }

    private static List<String> getCandiAN(List<String> ANs, Module module){
        List<String> candiAN = new ArrayList<>();
        String pkg2 = module.getName().replaceAll("/",".");
        addCandiAN(candiAN, ANs, pkg2);
        for (PackagePoint pp : module.getPackagePoints().values()){
            String pkgName = pp.getPkgName().replaceAll("/",".");
            String tmp = pkgName.replaceAll("\\.","");
            if ((pkgName.length() - tmp.length()) >= 2){
                addCandiAN(candiAN, ANs, pkgName);
            }
        }
        return candiAN;
    }

    private static void addCandiAN(List<String> candiAN, List<String> ANs, String pkgName){
        double max = 0;
        String maxS = "";
        for (String an : ANs){
            double pctM = compare2pkgs(an, pkgName);
            if (pctM == 1.0){
                candiAN.add(an);
            } else if (pctM > max && pctM >= 0.5){
                max = pctM;
                maxS = an;
            }
        }
        if (candiAN.size() == 0 && max >= 0.5){
            candiAN.add(maxS);
        }
    }

    private static double compare2pkgs(String pkg1, String pkg2){
        double result = 0;

        if (!pkg1.contains(".") && pkg2.contains(".")){
            String ele2 = pkg2.split("\\.")[0];
            if (pkg1.equals(ele2)){
                result = 1;
            }
        }else if (pkg1.contains(".") && pkg2.contains(".")){
            String[] ele1 = pkg1.split("\\.");
            String[] ele2 = pkg2.split("\\.");
            int len = ele1.length-1;
            int sum = 0;
            for (int i=1; i<ele1.length; i++){
                sum += Math.pow(2,i);
            }
            for (int i=1; i<ele1.length && i<ele2.length; i++){
                if (ele1[i].equals(ele2[i])){
                    result += Math.pow(2,len-i+1);
                }
            }
            result = result/sum;
        }else if (pkg1.equals(pkg2)){
            result = 1;
        }
        return result;
    }

    private static boolean isConfuse(String pkgName){
        boolean flag = true;
        if (pkgName.contains("/")){
            String[] splitName = pkgName.split("/");
            for (int i=0; i<splitName.length; i++){
                if (splitName[i].length()>1){
                    flag = false;
                }
            }
        }else if (pkgName.length()>1){
            flag = false;
        }
        return flag;
    }
}
