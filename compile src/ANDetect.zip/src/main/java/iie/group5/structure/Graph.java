package iie.group5.structure;

import java.util.*;

public class Graph {
    private Map<String, Vertex> vertices;
    private List<Vertex> vIDs;
    private int vtCount;
    private Map<Integer, List<Integer>> commV;
    private Map<Integer, Integer> commW;
    private Map<Integer, Integer> commO;

    public Graph() {
        this.vertices = new HashMap<>();
        this.vIDs = new ArrayList<>();
        this.commV = new HashMap<>();
        this.commW = new HashMap<>();
        this.commO = new HashMap<>();
        this.vtCount = 0;
    }

    public class Vertex{
        private Integer ID;
        private String label;
        private Integer communityID;
        private Map<Integer, Integer> outEdges;
        private Map<Integer, Integer> inEdges;

        public Vertex(Integer ID, String label) {
            this.ID = ID;
            this.label = label;
            this.outEdges = new HashMap<>();
            this.inEdges = new HashMap<>();
        }

        public void addOutEdge(int weight, Integer toID){
            if (this.outEdges.size() == 0 || !this.outEdges.containsKey(toID)){
                this.outEdges.put(toID, weight);
            }else{
                int newWeight = this.outEdges.get(toID);
                this.outEdges.put(toID, newWeight + weight);
            }
        }

        public void addInEdge(int weight, Integer inID){
            if (this.inEdges.size() == 0 || !this.inEdges.containsKey(inID)){
                this.inEdges.put(inID, weight);
            }else{
                int newWeight = this.inEdges.get(inID);
                this.inEdges.put(inID, newWeight + weight);
            }
        }

        public int selectOutWeight(){
            int outWeight = 0;
            if (this.outEdges.size() > 0){
                for (int w : this.outEdges.values()){
                    outWeight += w;
                }
            }
            return outWeight;
        }

        public int selectInWeight(){
            int inWeight = 0;
            if (this.inEdges.size() > 0){
                for (int w : this.inEdges.values()){
                    inWeight += w;
                }
            }
            return inWeight;
        }

        public Integer getID() {
            return ID;
        }

        public String getLabel() {
            return label;
        }

        public Map<Integer, Integer> getOutEdges() {
            return outEdges;
        }

        public Map<Integer, Integer> getInEdges() {
            return inEdges;
        }

        public Integer getCommunityID() {
            return communityID;
        }

        public void setCommunityID(Integer communityID) {
            this.communityID = communityID;
        }
    }


    public void insertVertex(String label){
        if (!this.vertices.containsKey(label)){
            Vertex vertex = new Vertex(this.vtCount++, label);
            this.vertices.put(label, vertex);
            this.vIDs.add(vertex);
        }
    }

    public void insertEdge(String fromLabel, String toLabel, int weight){
        Vertex fromV = this.vertices.get(fromLabel);
        Vertex toV = this.vertices.get(toLabel);
        if (fromV == null || toV == null){
            System.out.printf("Insert Edge Error! Don't have %s or %s.", fromLabel, toLabel);
        }else{
            fromV.addOutEdge(weight, toV.getID());
            toV.addInEdge(weight, fromV.getID());
        }
    }

    private int sumWeight(){
        int sw = 0;
        for (Vertex v : this.vIDs){
            sw += v.selectOutWeight();
        }
        return sw;
    }

    private int findWeight(Integer fromID, Integer toID){
        int result = 0;
        Vertex fromV = this.vIDs.get(fromID);
        if (fromV.getOutEdges().containsKey(toID)){
            result = fromV.getOutEdges().get(toID);
        }
        return result;
    }

    public boolean inGraph(String label){
        return this.vertices.containsKey(label);
    }

    public Integer commIDbyLable(String label){
        Integer commID = -1;
        if (!inGraph(label)){
            System.out.printf("%s not in community!", label);
        }else{
            Vertex v = this.vertices.get(label);
            commID = v.getCommunityID();
        }
        return commID;
    }

    public int commContribute(String label){
        int contri = 0;
        if (!inGraph(label)){
            System.out.printf("%s not in community!", label);
        }else{
            Vertex v = this.vertices.get(label);
            Integer commID = v.getCommunityID();
            for (Integer in : v.getInEdges().keySet()){
                if (this.vIDs.get(in).getCommunityID().equals(commID)){
                    contri += 1;
                }
            }
            for (Integer out : v.getOutEdges().keySet()){
                if (this.vIDs.get(out).getCommunityID().equals(commID)){
                    contri += 1;
                }
            }
        }
        return contri;
    }

    public Integer getCommbyV(Integer vID){
        Vertex vertex = this.vIDs.get(vID);
        return vertex.getCommunityID();
    }

    public Map<String, Vertex> getVertices() {
        return vertices;
    }

    public Integer getVtCount() {
        return this.vtCount;
    }


    private double deltaQ(Integer VID, Integer commID, double w){
        Vertex tmpV = this.vIDs.get(VID);
        Integer origComm = tmpV.getCommunityID();
        int deltaW = weight_Ci(commID, VID) + weight_iC(VID, commID) - weight_Ci(origComm, VID) - weight_Ci(VID, origComm);
        int sumTOT = (tmpV.selectOutWeight() * this.commW.get(commID) + tmpV.selectInWeight() * this.commO.get(commID)) -
                (tmpV.selectOutWeight() * (this.commW.get(origComm) - tmpV.selectInWeight()) + tmpV.selectInWeight() * (this.commO.get(origComm) - tmpV.selectOutWeight()));
        return deltaW - sumTOT/w;
    }

    private double calQ(double w){
        double Q = 0;
        for (Vertex i : this.vIDs){
            for (Vertex j : this.vIDs){
                if (i != j && i.getCommunityID().equals(j.getCommunityID())){
                    double w_ij = findWeight(i.getID(), j.getID());
                    int sisj = i.selectInWeight() * j.selectOutWeight();
                    Q += w_ij - sisj/w;
                }
            }
        }
        return Q / w;
    }

    private void initC(){
        for (Vertex v : this.vIDs){
            int commID = v.getCommunityID();
            if (!this.commV.containsKey(commID)){
                List<Integer> vs = new ArrayList<>();
                vs.add(v.getID());
                this.commV.put(commID, vs);
                int weight = v.selectInWeight();
                this.commW.put(commID, weight);
                weight = v.selectOutWeight();
                this.commO.put(commID, weight);
            }else{
                List<Integer> vs = this.commV.get(commID);
                vs.add(v.getID());
                this.commV.put(commID, vs);
                int weight = v.selectInWeight();
                this.commW.put(commID, weight + this.commW.get(commID));
                weight = v.selectOutWeight();
                this.commO.put(commID, weight + this.commO.get(commID));
            }
        }
    }

    private int weight_iC(int vID, int commID){
        List<Integer> toV = this.commV.get(commID);
        int weight = 0;
        for (Integer j : toV){
            weight += findWeight(vID, j);
        }
        return weight;
    }

    private int weight_Ci(int commID, int vID){
        List<Integer> fromV = this.commV.get(commID);
        int weight = 0;
        for (Integer j : fromV){
            weight += findWeight(j, vID);
        }
        return weight;
    }

    private void rollback(Map<Integer, Integer> origComm){
        for (Integer i : origComm.keySet()){
            Vertex v = this.vIDs.get(i);
            v.setCommunityID(origComm.get(i));
        }
    }

    public double singleLouvain(){
        for (Vertex v : this.vIDs){
            v.setCommunityID(v.getID());
        }
        double w = sumWeight();
        initC();
        double lastQ = calQ(w);
        boolean flag = true;
        while (flag){
            flag = false;
            Map<Integer, Integer> id2comm = new HashMap<>();
            for (Vertex v : this.vIDs){
                Integer vID = v.getID();
                id2comm.put(vID, v.getCommunityID());
                if (v.getOutEdges().size() > 0){
                    double maxQ = 0;
                    Integer maxNeigh = -1;
                    Integer oldCommID = v.getCommunityID();
                    for (Integer neigh : v.getOutEdges().keySet()){
                        Integer neighComm = this.vIDs.get(neigh).getCommunityID();
                        if (!oldCommID.equals(neighComm)){
                            double deltaQ = deltaQ(vID, neighComm, w);
                            if (deltaQ > maxQ){
                                maxQ = deltaQ;
                                maxNeigh = neighComm;
                            }
                        }
                    }
                    if (maxNeigh != -1){
                        v.setCommunityID(maxNeigh);
                        List<Integer> oldComm = this.commV.get(oldCommID);
                        List<Integer> newComm = this.commV.get(maxNeigh);
                        oldComm.remove(v.getID());
                        newComm.add(v.getID());
                        this.commV.put(oldCommID, oldComm);
                        this.commV.put(maxNeigh, newComm);
                        this.commW.put(oldCommID, this.commW.get(oldCommID)-v.selectInWeight());
                        this.commW.put(maxNeigh, this.commW.get(maxNeigh)+v.selectInWeight());
                        this.commO.put(oldCommID, this.commO.get(oldCommID)-v.selectOutWeight());
                        this.commO.put(maxNeigh, this.commO.get(maxNeigh)+v.selectOutWeight());
                    }
                    if (maxQ > 0){
                        flag = true;
                    }
                }
            }
            double allQ = calQ(w);
            double deltaQ = allQ-lastQ;
            if (deltaQ<=0){
                rollback(id2comm);
                break;
            }else {
                lastQ = allQ;
            }
        }
        return lastQ;
    }

    private Map<Integer, List<String>> countComm(){
        Map<Integer, List<String>> commLabel = new HashMap<>();

        for (Vertex v : this.vIDs){
            Integer commID = v.getCommunityID();
            String label = v.getLabel();
            if (!commLabel.containsKey(commID)){
                List<String> newlabel = new ArrayList<>();
                newlabel.add(label);
                commLabel.put(commID, newlabel);
            }else{
                commLabel.get(commID).add(label);
            }
        }
        return commLabel;
    }

    public void outputComm(){
        Map<Integer, List<String>> commLabel = countComm();
        System.out.printf("Total %d communities!\n", commLabel.size());
        for (Integer commID : commLabel.keySet()){
            System.out.printf("Community: %d\n", commID);
            for (String label : commLabel.get(commID)){
                System.out.printf("%s ", label);
            }
            System.out.println("\n--------------------");
        }
    }
}
