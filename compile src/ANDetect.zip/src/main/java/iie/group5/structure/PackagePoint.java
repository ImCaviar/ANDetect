package iie.group5.structure;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PackagePoint implements Serializable {
    private Integer id;
    private String label;
    private Integer parentId;
    private transient List<Integer> childrenID;
    private transient String pkgName;
    private transient Integer contribute;
    private transient boolean term;

    public PackagePoint() {
    }

    public PackagePoint(Integer id, String label, Integer parentId) {
        this.id = id;
        this.label = label;
        this.parentId = parentId;
        this.childrenID = new ArrayList<>();
        this.pkgName = "";
        this.term = false;
        this.contribute = 0;
    }

    public PackagePoint(PackagePoint packagePoint){
        this.id = packagePoint.getId();
        this.label = packagePoint.getLabel();
        this.parentId = packagePoint.getParentId();
        this.childrenID = packagePoint.getChildrenID();
        this.pkgName = packagePoint.getPkgName();
        this.term = false;
        this.contribute = packagePoint.getContribute();
    }

    public void addChildID(Integer cID){
        this.childrenID.add(cID);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public List<Integer> getChildrenID() {
        return childrenID;
    }

    public void setChildrenID(List<Integer> childrenID) {
        this.childrenID = childrenID;
    }

    public String getPkgName() {
        return pkgName;
    }

    public void setPkgName(String pkgName) {
        this.pkgName = pkgName;
    }

    public Integer getContribute() {
        return contribute;
    }

    public void setContribute(Integer contribute) {
        this.contribute = contribute;
    }

    public boolean isTerm() {
        return term;
    }

    public void setTerm(boolean term) {
        this.term = term;
    }
}
